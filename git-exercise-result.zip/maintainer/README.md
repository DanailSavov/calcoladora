# CalculatorApp

Simple console calculator used for the Git exercise.
